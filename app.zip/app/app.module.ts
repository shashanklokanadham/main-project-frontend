import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home/home.component';
import { ResourceComponent } from './resource/resource/resource.component';
import { ProjectComponent } from './project/project/project.component';
import { HttpClientModule } from '@angular/common/http'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
// import { ResourceDetailsComponent } from './resource/resource-details/resource-details.component';
import { ResourceService } from './resource/resource.service';
import { ProjectService } from './project/project.service';
import { ResourceListComponent } from './resource/resource-list/resource-list.component';
import { ProjectListComponent } from './project/project-list/project-list.component';
import { MaterialModule } from './material/material.module';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ResourceComponent,
    ProjectComponent,
    // ResourceDetailsComponent,
    ResourceListComponent,
    ProjectListComponent,
    PageNotFoundComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [ResourceService,ProjectService],
  entryComponents:[ResourceComponent,ProjectComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
