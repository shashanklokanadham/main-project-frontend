import { NgModule } from '@angular/core';
import { MatDialogModule, MatCardModule, MatIconModule, MatToolbarModule, MatTableModule, MatSortModule, MatPaginatorModule, MatInputModule, MatDatepickerModule, MatNativeDateModule, MatButtonModule } from '@angular/material';

const MaterComponents = [
  MatCardModule,
  MatIconModule,
  MatToolbarModule,
  MatDialogModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  MatInputModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatButtonModule
];

@NgModule({
  
  imports: [MaterComponents],
  exports: [MaterComponents]
})
export class MaterialModule { }
