import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, Sort, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ResourceService } from '../resource.service';
import { ResourceComponent } from '../resource/resource.component';
import { resourceDetails } from '../resource/resourceDetails';

@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {
  isPopupOpened=false
  searchKey: string;
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['employeeNo', 'unit', 'clientManager', 'ntidCreated', 'startDate', 'endDate', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private dialog?:MatDialog,private service?:ResourceService) { 

    this.sortedData = this.resourcesList.slice();
  }
// ngAfterViewInit() {
//     this.dataSource.paginator = this.paginator;
//     this.dataSource.sort = this.sort;
//   }
  sortedData:resourceDetails[];
  ngOnInit() {
    this.service.getResource();
    this.listData = new MatTableDataSource(this.resourcesList);
    this.listData.sort = this.sort;
    this.listData.paginator = this.paginator;
  }
  get resourcesList(){
    return this.service.getResource()
  }
  
  add(){
    this.isPopupOpened=true
    const dialogRef=this.dialog.open(ResourceComponent,{
      width: '500px',
      data:{}
    }
      )
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
    this.sortedData = this.resourcesList.slice();
    // this.listData = new MatTableDataSource(this.resourcesList);
    // this.listData.sort = this.sort;
    // this.listData.paginator = this.paginator;
  }
  editResource(employeeNo: number) {
    this.isPopupOpened = true
    const resource = this.service.getResource().find(c => c.employeeNo === employeeNo)
    const dialogRef = this.dialog.open(ResourceComponent, {
      width: '500px',
      data: {resource}
    })
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
    this.sortedData = this.resourcesList.slice();

  }
  deleteResource(employeeNo: number) {
    
    // this.sortedData = this.resourcesList.slice();
    this.service.deleteResource(employeeNo)
    this.listData = new MatTableDataSource(this.resourcesList.slice());
    this.listData.paginator = this.paginator;
  }
  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }
  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }
}
function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}