import { Injectable } from '@angular/core'; 
import { FormGroup ,FormControl, Validators} from '@angular/forms';
import { resourceDetails } from './resource/resourceDetails';
import { HttpClient } from '@angular/common/http';
import { resource } from 'selenium-webdriver/http';
@Injectable({
  providedIn: 'root'
})
export class ResourceService {
  resourceList: resourceDetails[] = [
    {
      "employeeNo": 1001,
      "unit": "ABC",
      "clientManager": "First",
      "ntidCreated": "YES",
      "startDate": "01-03-2019",
      "endDate": "01-04-2019",
      "infyManager": "QWERTY"
    },
    {
      "employeeNo": 1002,
      "unit": "ABC",
      "clientManager": "alkseufh",
      "ntidCreated": "NO",
      "startDate": "02-03-2019",
      "endDate": "02-04-2019",
      "infyManager": "ABCD"
    },
    {
      "employeeNo": 1003,
      "unit": "ABC",
      "clientManager": "klesfjh",
      "ntidCreated": "NO",
      "startDate": "03-03-2019",
      "endDate": "03-04-2019",
      "infyManager": "QWERTY"
    },
    {
      "employeeNo": 1004,
      "unit": "ABC",
      "clientManager": "lqekrh",
      "ntidCreated": "NO",
      "startDate": "04-03-2019",
      "endDate": "04-04-2019",
      "infyManager": "QWERTY"
    },
    {
      "employeeNo": 1005,
      "unit": "ABC",
      "clientManager": "qaweiofh",
      "ntidCreated": "NO",
      "startDate": "05-03-2019",
      "endDate": "05-04-2019",
      "infyManager": "ABCD"
    }
  ]
  // form: FormGroup = new FormGroup({
  //   employeeNo: new FormControl('', Validators.required),
  //   unit: new FormControl('', Validators.required),
  //   clientManager: new FormControl('', Validators.required),
  //   ntidCreated: new FormControl('', Validators.required),
  //   startDate: new FormControl('', Validators.required),
  //   endDate: new FormControl('', Validators.required),
  //   infyManager: new FormControl('', Validators.required)
  // });
  getResource(){
    // this.httpService.get('./assets/resource.json').subscribe(
    //   data => {
    //     this.resourceList = data as resourceDetails[];
    //   }
    // )
    return this.resourceList;
  }
  addResource(resource:resourceDetails){
    this.resourceList.push(resource)
  } 
  editResource(resource:resourceDetails){
    const index = this.resourceList.findIndex(c => c.employeeNo === resource.employeeNo)
    this.resourceList[index] = resource
  }
  deleteResource(employeeNo: number) {
    const resource = this.resourceList.findIndex(c => c.employeeNo === employeeNo)
    this.resourceList.splice(resource, 1)
  }
  // populateForm(resource:resourceDetails) {
  //   this..setValue(resource);
  // }
  constructor(private httpService: HttpClient) { }
}