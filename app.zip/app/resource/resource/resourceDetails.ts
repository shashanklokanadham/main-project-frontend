export class resourceDetails
{
		"employeeNo":number;
		"unit":string;
		"clientManager":string
		"ntidCreated":string
		"startDate":string;
		"endDate":string;
		"infyManager":string;
}