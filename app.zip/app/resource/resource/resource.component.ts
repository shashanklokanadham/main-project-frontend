import { Component, OnInit, Inject } from '@angular/core';


import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

import { ResourceService } from '../resource.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-resource',
  templateUrl: './resource.component.html',
  styleUrls: ['./resource.component.css']
})
export class ResourceComponent implements OnInit {

  constructor(private fb: FormBuilder, private dialogRef: MatDialogRef<ResourceComponent>,private service: ResourceService,@Inject(MAT_DIALOG_DATA) public data:any) { }
  public resourceForm:FormGroup;

  onNoClick():void{
    this.dialogRef.close();
  }
  ngOnInit() {
   this.resourceForm=this.fb.group({
      employeeNo: ['',[Validators.required]],
      unit: ['', [Validators.required]],
      clientManager: ['', [Validators.required]],
       ntidCreated: ['', [Validators.required]],
     startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      infyManager: ['', [Validators.required]]

     })
    // this.resourceForm = new FormGroup({
    //   $key: new FormControl(null),
    //   employeeNo: new FormControl('', Validators.required),
    //   unit: new FormControl('', Validators.required),
    //   clientManager: new FormControl('', Validators.required),
    //   ntidCreated: new FormControl('', Validators.required),
    //   startDate: new FormControl('', Validators.required),
    //   endDate: new FormControl('', Validators.required),
    //   infyManager: new FormControl('', Validators.required)
    // });
  }
  save(){
    if(isNaN(this.data.employeeNo))
    {
      this.service.addResource(this.resourceForm.value);
      this.dialogRef.close();
    }
    else{
      this.service.editResource(this.resourceForm.value);
      this.dialogRef.close();
    }
  }
}
