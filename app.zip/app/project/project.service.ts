import { Injectable } from '@angular/core';
import { projectDetails } from './project/projectDetails';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  
  projectList:projectDetails[]  =[
    {
      "projectName": "First Project",
      "projectRTN": 12345,
      "cwNumber": 9876,
      "chargeWorkOrderNo": 1823476,
      "projectStartDate": "01-03-2019",
      "projectEndDate": "01-04-2019",
      "workOrderValue": 10000,
      "workOrderManage": "First"
    },
    {
      "projectName": "Second Poject",
      "projectRTN": 67890,
      "cwNumber": 134543, 
      "chargeWorkOrderNo": 2346546,
      "projectStartDate": "02-03-2019",
      "projectEndDate": "02-04-2019",
      "workOrderValue": 20000,
      "workOrderManage": "Second"
    },
    {
      "projectName": "Third Project",
      "projectRTN": 123453,
      "cwNumber": 5624342,
      "chargeWorkOrderNo": 23456356,
      "projectStartDate": "03-03-2019",
      "projectEndDate": "03-04-2019",
      "workOrderValue": 30000,
      "workOrderManage": "Third"
    },
    {
      "projectName": "Fourth Project",
      "projectRTN": 345213,
      "cwNumber": 2345345,
      "chargeWorkOrderNo": 234534,
      "projectStartDate": "04-03-2019",
      "projectEndDate": "04-04-2019",
      "workOrderValue": 40000,
      "workOrderManage": "Fourth"
    },
    {
      "projectName": "Fifth Project",
      "projectRTN": 12345134,
      "cwNumber": 134556,
      "chargeWorkOrderNo": 45624,
      "projectStartDate": "05-03-2019",
      "projectEndDate": "05-04-2019",
      "workOrderValue": 50000,
      "workOrderManage": "Fifth"
    }
  ]
  constructor(private httpService: HttpClient) { }
  form:FormGroup=new FormGroup({
    key: new FormControl(null),
    projectName: new FormControl('', Validators.required),
    projectRTN: new FormControl('', Validators.required),
    cwNumber: new FormControl('', Validators.required),
    chargeWorkOrderNo: new FormControl('', Validators.required),
    projectStartDate: new FormControl('', Validators.required),
    projectEndDate: new FormControl('', Validators.required),
    workOrderValue: new FormControl('', Validators.required),
    workOrderManage: new FormControl('', Validators.required)
  })
  getProject(){
    // this.httpService.get('./assets/resource.json').subscribe(
    //   data => {
    //     this.projectList = data as projectDetails[];
    //   }
    // )
    return this.projectList
  }
  addProject(project:projectDetails){
    this.projectList.push(project)
  }
  deleteProject(projectName:string){
    const project=this.projectList.findIndex(c=>c.projectName===projectName)
    this.projectList.splice(project,1)
  }
  editProject(project:projectDetails){
    const index=this.projectList.findIndex(c=>c.projectName===project.projectName)
    this.projectList[index]=project
  }
  populateForm(project) {
    this.form.setValue(project);
  }
}