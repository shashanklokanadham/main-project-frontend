import { Inject,Component, OnInit } from '@angular/core';
import { projectDetails } from './projectDetails';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ProjectService } from '../project.service';
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  public projectForm: FormGroup;
  constructor(private fb: FormBuilder, private dialogRef: MatDialogRef<ProjectComponent>, private service: ProjectService, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    // this.projectForm = this.fb.group({
    //   projectName: [this.data.projectName, [Validators.required]],
    //   projectRTN: [this.data.projectRTN, [Validators.required]],
    //   cwNumber: [this.data.cwNumber, [Validators.required]],
    //   chargeWorkOrderNo: [this.data.chargeWorkOrderNo, [Validators.required]],
    //   projectStartDate: [this.data.projectStartDate, [Validators.required]],
    //   projectEndDate: [this.data.projectEndDate, [Validators.required]],
    //   workOrderValue: [this.data.workOrderValue, [Validators.required]],
    //   workOrderManage: [this.data.workOrderManage, [Validators.required]]

    // })
  }
  save() {
    if(isNaN(this.data.projectRTN))
    {
      this.service.addProject(this.service.form.value);
      this.dialogRef.close();
    }
    else
    {
      this.service.editProject(this.service.form.value);
      this.dialogRef.close();
    }
  }


}
