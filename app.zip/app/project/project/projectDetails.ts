export class projectDetails
{
		"projectName":string;
		"projectRTN":number;
		"cwNumber":number;
		"chargeWorkOrderNo":number;
		"projectStartDate":string;
		"projectEndDate":string;
		"workOrderValue":number;
		"workOrderManage":string;
}