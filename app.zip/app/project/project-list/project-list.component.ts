import { Component, OnInit, ViewChild } from '@angular/core';
import { ProjectService } from '../project.service';
import { MatPaginator, MatDialog, MatTableDataSource, MatSort, MatDialogConfig } from '@angular/material';
import { ProjectComponent } from '../project/project.component';
import { projectDetails } from '../project/projectDetails';
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  isPopupOpened = false
  displayedColumns: string[] = ['projectName', 'projectRTN', 'cwNumber', 'chargeWorkOrderNo', 'projectStartDate', 'projectEndDate', 'workOrderValue', 'workOrderManage','actions'];
  sortedData:projectDetails[];
  listData:MatTableDataSource<any>;
  searchKey:string;
  constructor(private dialog?: MatDialog, private service?: ProjectService) {
    this.sortedData = this.projectList.slice();
  }
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.service.getProject();
    this.listData = new MatTableDataSource(this.projectList);
    this.listData.sort = this.sort;
    this.listData.paginator=this.paginator;
  }
  get projectList() {
    return this.service.getProject()
  }
 
  add() {
    this.isPopupOpened = true
    const dialogRef = this.dialog.open(ProjectComponent, {
      width: '500px',
      data: {}
    })
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
    this.listData = new MatTableDataSource(this.projectList.slice());

}
deleteProject(projectName:string){
  this.service.deleteProject(projectName)
  this.listData = new MatTableDataSource(this.projectList.slice());
  this.listData.paginator = this.paginator;


}
  editProject(projectName:string){
    this.isPopupOpened = true
    const project=this.service.getProject().find(c=>c.projectName===projectName)
    const dialogRef = this.dialog.open(ProjectComponent, {
      width: '500px',
      data: project
    })
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
    })
  }
  // editProject(row) {

  //   this.service.populateForm(row);
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose=true;
  //   dialogConfig.autoFocus= true;
  //   dialogConfig.width ="60%";
  //   this.dialog.open(ProjectComponent,dialogConfig);
  // }
  onSearchClear(){
    this.searchKey="";
    this.applyFilter();
  }
  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }
}
function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}