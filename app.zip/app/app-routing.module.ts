import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home/home.component';
import { ResourceListComponent } from './resource/resource-list/resource-list.component';
import { ProjectListComponent } from './project/project-list/project-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';


const routes: Routes = [
  
  {
    path: 'home', component:HomeComponent
  },
  {
    path: 'project', component: ProjectListComponent,
  },
  {
  path: 'resource', component: ResourceListComponent,
  },
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
